# CCMS - Power BI Style Analytics Dashboard (Jet Black Edition)

This archive contains the complete frontend source code for the CCMS Complaint Intelligence & Spatial Analytics Dashboard.

## Package Contents

- **analytics/**:
  - `InteractiveAnalyticsDashboard.jsx`: Main Executive Dashboard canvas featuring dimensional cross-filtering.
  - `components/`:
    - `CampusMapCard.jsx`: Interactive architectural campus map with 9 buildings, 2D/3D toggle, zone slider, facility pills.
    - `DepartmentDivisionAnalytics.jsx`: Vertical column bar charts for Departments & SLA MTTR turnaround, with conditional class division drill-down.
    - `ComplaintTrendCard.jsx`: 8-week timeline scrubber with range selection & area fill.
    - `CategoryDonutCard.jsx`: High-precision SVG Donut Chart covering all 8 institutional complaint categories.
    - `PowerBiPivotMatrix.jsx`: Excel / Power BI cross-tabulation matrix with category-to-facility drill-downs.
    - `KpiSparklineCards.jsx`: 4 KPI cards with SVG wave glow sparklines.
    - `ComplaintInspectModal.jsx`: Detailed ticket inspection dialog with root cause and reporter diagnosis.
    - ... (additional modular telemetry and leaderboard components)
  - `data/`:
    - `ccmsAnalyticsData.js`: Procedural data engine generating 480 realistic campus complaints across October 2026.
- **assets/**:
  - `campus_map_user.jpg`: Campus masterplan overhead architectural render.

## Key Technical Specifications

1. **Pure Jet Black OLED Aesthetics**: `#050505` / `#000000`, 100% borderless presentation with dark contrasts.
2. **Vertical Column Bar Charts**: Columns rising vertically from bottom to top for departments (Inflow vs Resolved) and SLA compliance (On-time, Warning, Breached) with MTTR benchmarks.
3. **Conditional Division Ribbon**: The class division section is hidden until a specific academic department is selected, keeping the canvas minimal and clutter-free.
4. **Cross-Filtering Telemetry**: Interacting with any chart (clicking a department bar, severity column, map pin, or donut segment) instantly cross-filters all other components simultaneously.

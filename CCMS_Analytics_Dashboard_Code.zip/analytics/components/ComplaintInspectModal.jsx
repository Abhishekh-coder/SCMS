import React from 'react';
import { 
  X, AlertOctagon, User, Building, MapPin, 
  Calendar, Clock, CheckCircle2 
} from 'lucide-react';

export default function ComplaintInspectModal({
  complaint,
  onClose
}) {
  if (!complaint) return null;

  const sevColor = complaint.severity === 'Critical'
    ? 'bg-[#2a080c] text-rose-300'
    : complaint.severity === 'High'
    ? 'bg-[#261204] text-orange-300'
    : 'bg-[#261d04] text-amber-300';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div 
        className="bg-[#050505] rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-5 flex items-start justify-between bg-[#000000]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="font-mono font-medium text-xs bg-[#141414] text-cyan-400 px-2.5 py-0.5 rounded-full">
                {complaint.id}
              </span>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${sevColor}`}>
                {complaint.severity} Priority
              </span>
              <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#141414] text-slate-300">
                {complaint.status}
              </span>
              {complaint.slaStatus === 'Breached' && (
                <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-[#2a080c] text-rose-400 flex items-center gap-1">
                  <AlertOctagon className="w-3 h-3" /> SLA Breached
                </span>
              )}
            </div>
            <h2 className="text-base font-bold text-slate-100 leading-snug">
              {complaint.title}
            </h2>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-[#141414] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-300 bg-[#050505]">
          
          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0a0a0a] p-3 rounded-xl">
            <div>
              <span className="text-slate-400 text-[10px] block">Category</span>
              <span className="font-medium text-slate-200">{complaint.category}</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">Department</span>
              <span className="font-medium text-slate-200">{complaint.departmentName}</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">Location</span>
              <span className="font-medium text-slate-200">{complaint.location}</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">Turnaround</span>
              <span className="font-medium text-slate-200">{complaint.resolutionHours}h</span>
            </div>
          </div>

          {/* Root cause analysis */}
          <div>
            <h4 className="text-xs font-semibold text-slate-200 mb-1">
              Diagnosis & Root Cause
            </h4>
            <div className="bg-[#0a0a0a] p-3 rounded-xl text-slate-300">
              {complaint.rootCause}
            </div>
          </div>

          {/* Assigned & Reporter */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="bg-[#0a0a0a] p-3 rounded-xl flex items-center gap-2.5">
              <User className="w-4 h-4 text-slate-400 shrink-0" />
              <div>
                <span className="text-[10px] text-slate-400 block">Reporter</span>
                <span className="font-medium text-slate-200">{complaint.reporter}</span>
              </div>
            </div>

            <div className="bg-[#0a0a0a] p-3 rounded-xl flex items-center gap-2.5">
              <Building className="w-4 h-4 text-slate-400 shrink-0" />
              <div>
                <span className="text-[10px] text-slate-400 block">Assigned Unit</span>
                <span className="font-medium text-slate-200">{complaint.assignedTo}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#000000] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-300 bg-[#141414] hover:bg-[#202020] rounded-xl transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

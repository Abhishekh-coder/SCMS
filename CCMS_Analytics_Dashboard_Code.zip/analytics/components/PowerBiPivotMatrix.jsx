import React, { useState, useMemo } from 'react';
import { Table, Eye, ChevronRight, ChevronDown, ArrowUpDown, FileSpreadsheet } from 'lucide-react';

export default function PowerBiPivotMatrix({
  complaints = [],
  categories = [],
  onInspectComplaint,
  onToggleCategory,
  activeCategory
}) {
  const [viewMode, setViewMode] = useState('pivot'); // 'pivot' | 'flat'
  const [expandedCats, setExpandedCats] = useState({});

  const toggleExpand = (catId) => {
    setExpandedCats(prev => ({
      ...prev,
      [catId]: !prev[catId]
    }));
  };

  // Group data like an Excel Pivot Table (Category -> Buildings -> Aggregated Metrics)
  const pivotData = useMemo(() => {
    return categories.map((cat) => {
      const catComplaints = complaints.filter(c => c.category === cat.id);
      const total = catComplaints.length;
      const resolved = catComplaints.filter(c => c.status === 'Resolved' || c.status === 'Closed').length;
      const inProgress = catComplaints.filter(c => c.status === 'In Progress' || c.status === 'Under Investigation').length;
      const escalated = catComplaints.filter(c => c.status === 'Escalated').length;
      const critical = catComplaints.filter(c => c.severity === 'Critical').length;
      const breached = catComplaints.filter(c => c.slaStatus === 'Breached').length;
      const totalHours = catComplaints.reduce((acc, c) => acc + (c.resolutionHours || 0), 0);
      const avgHours = total > 0 ? (totalHours / total).toFixed(1) : '0.0';

      // Sub-rows by Building
      const buildingGroups = {};
      catComplaints.forEach(c => {
        if (!buildingGroups[c.building]) {
          buildingGroups[c.building] = [];
        }
        buildingGroups[c.building].push(c);
      });

      const subRows = Object.entries(buildingGroups).map(([bldgName, bItems]) => {
        const bTotal = bItems.length;
        const bResolved = bItems.filter(c => c.status === 'Resolved' || c.status === 'Closed').length;
        const bInProgress = bItems.filter(c => c.status === 'In Progress' || c.status === 'Under Investigation').length;
        const bEscalated = bItems.filter(c => c.status === 'Escalated').length;
        const bCritical = bItems.filter(c => c.severity === 'Critical').length;
        const bBreached = bItems.filter(c => c.slaStatus === 'Breached').length;
        const bHours = bItems.reduce((acc, c) => acc + (c.resolutionHours || 0), 0);

        return {
          name: bldgName,
          total: bTotal,
          resolved: bResolved,
          inProgress: bInProgress,
          escalated: bEscalated,
          critical: bCritical,
          breached: bBreached,
          avgHours: bTotal > 0 ? (bHours / bTotal).toFixed(1) : '0.0'
        };
      }).sort((a, b) => b.total - a.total);

      return {
        ...cat,
        total,
        resolved,
        inProgress,
        escalated,
        critical,
        breached,
        avgHours,
        subRows
      };
    }).filter(c => c.total > 0).sort((a, b) => b.total - a.total);
  }, [complaints, categories]);

  // Overall Totals
  const grandTotal = complaints.length;
  const grandResolved = complaints.filter(c => c.status === 'Resolved' || c.status === 'Closed').length;
  const grandInProgress = complaints.filter(c => c.status === 'In Progress' || c.status === 'Under Investigation').length;
  const grandEscalated = complaints.filter(c => c.status === 'Escalated').length;
  const grandCritical = complaints.filter(c => c.severity === 'Critical').length;
  const grandBreached = complaints.filter(c => c.slaStatus === 'Breached').length;

  return (
    <div className="bg-[#050505] rounded-2xl overflow-hidden select-none mb-4">
      
      {/* Pivot Table Header (Jet Black, borderless) */}
      <div className="p-4 flex flex-wrap items-center justify-between gap-3 bg-[#000000]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#141414] text-emerald-400 flex items-center justify-center">
            <FileSpreadsheet className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-2">
              <span>Executive Pivot Matrix & Cross-Tabulation</span>
              <span className="text-[10px] font-mono font-bold bg-[#141414] text-emerald-400 px-2.5 py-0.5 rounded-full">
                Power BI Model
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">
              Interactive dimensional pivot table: Click category to expand building drill-downs
            </p>
          </div>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[#101010] p-0.5 rounded-xl text-xs font-semibold">
            <button
              onClick={() => setViewMode('pivot')}
              className={`px-3 py-1 rounded-lg transition-all ${
                viewMode === 'pivot'
                  ? 'bg-[#202020] text-emerald-400 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Pivot Matrix
            </button>
            <button
              onClick={() => setViewMode('flat')}
              className={`px-3 py-1 rounded-lg transition-all ${
                viewMode === 'flat'
                  ? 'bg-[#202020] text-emerald-400 font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Recent Records ({complaints.length})
            </button>
          </div>
        </div>
      </div>

      {/* Mode 1: Excel / Power BI Style Pivot Matrix */}
      {viewMode === 'pivot' ? (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-sans">
            <thead>
              <tr className="bg-[#0a0a0a] text-slate-400 text-[11px] font-semibold uppercase tracking-wider">
                <th className="py-3 px-4">Category / Facility Drill-down</th>
                <th className="py-3 px-3 text-right">Total Cases</th>
                <th className="py-3 px-3 text-right">Resolved</th>
                <th className="py-3 px-3 text-right">In Progress</th>
                <th className="py-3 px-3 text-right">Escalated</th>
                <th className="py-3 px-3 text-right">Critical</th>
                <th className="py-3 px-3 text-right">SLA Breached</th>
                <th className="py-3 px-4 text-right">Avg MTTR</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#141414]">
              {pivotData.map((row) => {
                const isExpanded = expandedCats[row.id];
                const isActive = activeCategory === row.id;

                return (
                  <React.Fragment key={row.id}>
                    {/* Category Summary Row */}
                    <tr
                      onClick={() => toggleExpand(row.id)}
                      className={`cursor-pointer transition-colors ${
                        isActive
                          ? 'bg-[#181818]'
                          : isExpanded
                          ? 'bg-[#121212]'
                          : 'hover:bg-[#0f0f0f]'
                      }`}
                    >
                      <td className="py-2.5 px-4 font-semibold text-slate-100 flex items-center gap-2">
                        {isExpanded ? (
                          <ChevronDown className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                        )}
                        <span
                          className="w-2.5 h-2.5 rounded-full inline-block"
                          style={{ backgroundColor: row.color }}
                        />
                        <span>{row.label}</span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          ({row.subRows.length} facilities)
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-white">
                        {row.total}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-emerald-400">
                        {row.resolved}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-blue-400">
                        {row.inProgress}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-rose-400">
                        {row.escalated}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold text-red-400">
                        {row.critical}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-amber-400">
                        {row.breached}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono text-slate-300">
                        {row.avgHours}h
                      </td>
                    </tr>

                    {/* Sub-rows: Building Drill-downs */}
                    {isExpanded && row.subRows.map((sub) => (
                      <tr
                        key={sub.name}
                        className="bg-[#050505] text-slate-300 hover:bg-[#121212] text-[11px]"
                      >
                        <td className="py-1.5 pl-10 pr-4 flex items-center gap-2 text-slate-300">
                          <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                          <span>{sub.name}</span>
                        </td>
                        <td className="py-1.5 px-3 text-right font-mono font-medium text-slate-200">
                          {sub.total}
                        </td>
                        <td className="py-1.5 px-3 text-right font-mono text-emerald-400/90">
                          {sub.resolved}
                        </td>
                        <td className="py-1.5 px-3 text-right font-mono text-blue-400/90">
                          {sub.inProgress}
                        </td>
                        <td className="py-1.5 px-3 text-right font-mono text-rose-400/90">
                          {sub.escalated}
                        </td>
                        <td className="py-1.5 px-3 text-right font-mono text-red-400/90">
                          {sub.critical}
                        </td>
                        <td className="py-1.5 px-3 text-right font-mono text-amber-400/90">
                          {sub.breached}
                        </td>
                        <td className="py-1.5 px-4 text-right font-mono text-slate-400">
                          {sub.avgHours}h
                        </td>
                      </tr>
                    ))}
                  </React.Fragment>
                );
              })}
            </tbody>

            {/* Grand Total Row */}
            <tfoot>
              <tr className="bg-[#0a0a0a] text-white font-bold font-mono text-xs">
                <td className="py-3 px-4 font-sans uppercase tracking-wider text-emerald-400">
                  Total (All Categories)
                </td>
                <td className="py-3 px-3 text-right text-base text-white">{grandTotal}</td>
                <td className="py-3 px-3 text-right text-emerald-400">{grandResolved}</td>
                <td className="py-3 px-3 text-right text-blue-400">{grandInProgress}</td>
                <td className="py-3 px-3 text-right text-rose-400">{grandEscalated}</td>
                <td className="py-3 px-3 text-right text-red-400">{grandCritical}</td>
                <td className="py-3 px-3 text-right text-amber-400">{grandBreached}</td>
                <td className="py-3 px-4 text-right text-slate-300">--</td>
              </tr>
            </tfoot>
          </table>
        </div>
      ) : (
        /* Mode 2: Flat Recent Complaints List */
        <div className="overflow-x-auto max-h-[350px]">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="text-slate-400 text-[11px] font-medium bg-[#0a0a0a] sticky top-0">
                <th className="py-2.5 px-4">Tracking ID</th>
                <th className="py-2.5 px-4">Subject & Location</th>
                <th className="py-2.5 px-4">Category</th>
                <th className="py-2.5 px-4">Priority</th>
                <th className="py-2.5 px-4">Status</th>
                <th className="py-2.5 px-4">SLA</th>
                <th className="py-2.5 px-4 text-right">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#141414]">
              {complaints.slice(0, 15).map((item) => (
                <tr
                  key={item.id}
                  onClick={() => onInspectComplaint(item)}
                  className="hover:bg-[#121212] cursor-pointer transition-colors"
                >
                  <td className="py-2.5 px-4 font-mono font-medium text-cyan-400">
                    {item.id}
                  </td>
                  <td className="py-2.5 px-4">
                    <p className="font-semibold text-slate-200 truncate">{item.title}</p>
                    <p className="text-[10px] text-slate-400">{item.location}</p>
                  </td>
                  <td className="py-2.5 px-4 text-slate-300">{item.category}</td>
                  <td className="py-2.5 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#141414] text-slate-200">
                      {item.severity}
                    </span>
                  </td>
                  <td className="py-2.5 px-4">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-[#141414] text-slate-300">
                      {item.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 font-mono text-[11px] text-slate-300">
                    {item.slaStatus}
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onInspectComplaint(item);
                      }}
                      className="p-1 text-slate-400 hover:text-cyan-400"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

    </div>
  );
}
